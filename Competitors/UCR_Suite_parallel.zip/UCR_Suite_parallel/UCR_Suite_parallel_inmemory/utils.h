/* 
 * File:   utils.h
 * Author: michele
 *
 * Created on October 25, 2014, 8:41 AM
 */

#ifndef UTILS_H
#define	UTILS_H



extern int numberOfCores;
int GetCPUCount();
double randnPersonal (double mu, double sigma);
unsigned long long getMemorySize( );



#endif	/* UTILS_H */
