/* 
 * File:   main.cpp
 * Author: michelelinardi
 *
 * Created on February 28, 2015, 4:56 PM
 */


/***********************************************************************/
/************************* DISCLAIMER **********************************/
/***********************************************************************/
/** This UCR Suite software is copyright protected © 2012 by          **/
/** Thanawin Rakthanmanon, Bilson Campana, Abdullah Mueen,            **/
/** Gustavo Batista and Eamonn Keogh.                                 **/
/**                                                                   **/
/** Unless stated otherwise, all software is provided free of charge. **/
/** As well, all software is provided on an "as is" basis without     **/
/** warranty of any kind, express or implied. Under no circumstances  **/
/** and under no legal theory, whether in tort, contract,or otherwise,**/
/** shall Thanawin Rakthanmanon, Bilson Campana, Abdullah Mueen,      **/
/** Gustavo Batista, or Eamonn Keogh be liable to you or to any other **/
/** person for any indirect, special, incidental, or consequential    **/
/** damages of any character including, without limitation, damages   **/
/** for loss of goodwill, work stoppage, computer failure or          **/
/** malfunction, or for any and all other damages or losses.          **/
/**                                                                   **/
/** If you do not agree with these terms, then you you are advised to **/
/** not use this software.                                            **/
/***********************************************************************/
/***********************************************************************/



#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include <sched.h>
#include <cmath>
#include <iostream>
#include <stdbool.h>
#include <fstream>


extern "C"
{
    #include "pqueue.h"
}
struct timeval total_time_start;
        struct timeval current_time;
        double tS,tE,total_time;

#define INF 1e20       //Pseudo Infitinte number for this code
        #define COUNT_TOTAL_TIME_START gettimeofday(&total_time_start, NULL);   
        #define COUNT_TOTAL_TIME_END  gettimeofday(&current_time, NULL); \
                                      tS = total_time_start.tv_sec*1000000 + (total_time_start.tv_usec); \
                                      tE = current_time.tv_sec*1000000  + (current_time.tv_usec); \
                                      total_time += (tE - tS); 


using namespace std;
typedef struct transfordata
{
    unsigned long  start_number;
    unsigned long  stop_number;
    double * bsfdistance;
    pthread_mutex_t *lock_bsf;
    long long totalDataPatterns;
    double * firsKResults;
    pqueue_t * resultQueue;
    long long pointCheckedTotal;
    double * Q;
    int * order;
}transfordata;
char const * datafilegl;
int mgl;
int full_time_series_sizegl;
int typegl;
double thresholdgl;
void * query_time_series(void *);
int trillion( char const *, char const*, int, int, double, int, int, int, int);
int simpleScan( char const * , int , int );


void pushDistValueInTheTopK(double * firsKResults, int k, float dist)
{
   int i;
   double valueToInsert =-1;
   for(i=0;i<k;i++)
   {
       if (valueToInsert >= 0)
       {
           double temporary = firsKResults[i];
           firsKResults[i] = valueToInsert;
           valueToInsert = temporary;
           
           if (valueToInsert<0)
           {
               break;
           }
           
       }
       else if(firsKResults[i] > dist || firsKResults[i]<0)
       {
           valueToInsert = firsKResults[i];
           firsKResults[i] =  dist;
           if (valueToInsert<0)
           {
               break;
           }
       }
   }

}

typedef struct query_result {
    float distance;
    long long location;
    int sizeOfQuery;
    size_t pqueue_position; 
} query_result;

static int
cmp_pri(double next, double curr)
{
	return (next > curr);
}


static double
get_pri(void *a)
{
	return (double) ((query_result *) a)->distance;
}


static void
set_pri(void *a, double pri)
{
	((query_result *) a)->distance = (float)pri;
}


static size_t
get_pos(void *a)
{
	return ((query_result *) a)->pqueue_position;
}


static void
set_pos(void *a, size_t pos)
{
	((query_result *) a)->pqueue_position = pos;
}

/// Data structure for sorting the query.
typedef struct Index
    {   double value;
        int    index;
    } Index;
    
    


/// Comparison function for sorting the query.
/// The query will be sorted by absolute z-normalization value, |z_norm(Q[i])| from high to low.
int comp(const void *a, const void* b)
{   Index* x = (Index*)a;
    Index* y = (Index*)b;
    return abs(y->value) - abs(x->value);
}


/// Main function for calculating ED distance between the query, Q, and current data, T.
/// Note that Q is already sorted by absolute z-normalization value, |z_norm(Q[i])|
//double distance(const double * const Q, const double * const T , const int& j , const int& m , const double& mean , const double& std , const int* const order, const double& bsf)
double distance(double * Q, double * T , const int& j , const int& m , const double& mean , const double& std , int* order, const double& bsf, int& pointChecked)
{
    int i;
    pointChecked=0;
    double sum = 0;
    for ( i = 0 ; i < m && sum < bsf ; i++ )
    {
        pointChecked= pointChecked+1;
        double x = (T[(order[i]+j)]-mean)/std;
        sum += (x-Q[i])*(x-Q[i]);
    }
    return sum;
}
double distancenormal(double * Q, double * T , const int& j , const int& m  , int* order, const double& bsf, int& pointChecked)
{
    int i;
    pointChecked=0;
    double sum = 0;
    for ( i = 0 ; i < m && sum < bsf ; i++ )
    {
        pointChecked= pointChecked+1;
        double x = T[(order[i]+j)];
        sum += (x-Q[i])*(x-Q[i]);
    }
    return sum;
}

/// If serious error happens, terminate the program.
void error(int id)
{
    if(id==1)
        printf("ERROR : Memory can't be allocated!!!\n\n");
    else if ( id == 2 )
        printf("ERROR : Dataset File not Found!!!\n\n");
    else if ( id == 3 )
        printf("ERROR : Query File not Found!!!\n\n");
    exit(1);
}

int main(  int argc , char *argv[] )
{
	
	if (argc <= 1)
	{
		printf("Usage: dataset file, query file, size of query, type (0/1 = eps/k-nn), threshold, num ts dataset, size ts dataset, query number,cpu_control_type\n");
		printf("\n\nOR for having the statistics of the disk access time for a dataset:\n");
		printf("Usage: dataset file, num ts dataset, size ts dataset\n");
         printf("cpu_control_type code:\n\
                       \t\t\t21 : 2 core in 1 CPU\n\
                       \t\t\t22 : 2 core in 2 CPUs\n\
                       \t\t\t41 : 4 core in 1 CPU\n\
                       \t\t\t42 : 4 core in 2 CPUs\n\
                       \t\t\t61 : 6 core in 1 CPU\n\
                       \t\t\t62 : 6 core in 2 CPUs\n\
                       \t\t\t81 : 8 core in 1 CPU\n\
                       \t\t\t82 : 8 core in 2 CPUs\n\
                       \t\t\t101: 10 core in 1 CPU\n\
                       \t\t\t102: 10 core in 2 CPUs\n\
                       \t\t\t121: 12 core in 1 CPU\n\
                       \t\t\t122: 12 core in 2 CPUs\n\
                       \t\t\t181: 18 core in 1 CPU\n\
                       \t\t\t182: 18 core in 2 CPUs\n\
                       \t\t\t242: 24 core in 2 CPUs\n\
                       \t\t\tOther: 1 core in 1 CPU\n");
	}
	else
	{
		if(argc == 4)
		{
			int ts_num = atoi(argv[2]);
			int full_time_series_size = atoi(argv[3]);
			simpleScan(argv[1],ts_num,full_time_series_size);
		}
		else
		{	
			int pidv=getpid();
        		char pidvalue[20];
		        sprintf(pidvalue,"%d",pidv);
        //printf("pid is :  %s\n",pidvalue);
        char mkdircommand[200] = "mkdir /home/pbotao/Documents/testcommand/piddiskvalue/";
        strcat(mkdircommand,pidvalue);
        char cpvalue[200] = "cp /proc/";
        strcat(cpvalue,pidvalue);
        strcat(cpvalue,"/io /home/pbotao/Documents/testcommand/piddiskvalue/");
        strcat(cpvalue,pidvalue);

			int size = atoi(argv[3]);
			int type = atoi(argv[4]);
			int threshold = atoi(argv[5]);
			int ts_num = atoi(argv[6]);
			int full_time_series_size = atoi(argv[7]);
      			int query_number = atoi(argv[8]);
      			int cpu_control_type = atoi(argv[9]);
			int calculate_thread=1;
        		int maxquerythread=1;
			cpu_set_t mask,get;
    			CPU_ZERO(&mask);
    			CPU_ZERO(&get);
			if(cpu_control_type==21)
    {
        CPU_SET(0, &mask);
        CPU_SET(2, &mask);
        calculate_thread=2;
        maxquerythread=2;
    }
    else if(cpu_control_type==22)
    {
        CPU_SET(0, &mask);
        CPU_SET(1, &mask);
        calculate_thread=2;
        maxquerythread=2;
    }
    else if(cpu_control_type==41)
    {
        CPU_SET(0, &mask);
        CPU_SET(2, &mask);
        CPU_SET(4, &mask);
        CPU_SET(6, &mask);
	    calculate_thread=4;
        maxquerythread=4;
    }
    else if(cpu_control_type==42)
    {
        CPU_SET(0, &mask);
        CPU_SET(1, &mask);
        CPU_SET(2, &mask);
        CPU_SET(3, &mask);
        calculate_thread=4;
        maxquerythread=4;
    }
    else if(cpu_control_type==61)
    {
        CPU_SET(0, &mask);
        CPU_SET(2, &mask);
        CPU_SET(4, &mask);
        CPU_SET(6, &mask);
        CPU_SET(8, &mask);
        CPU_SET(10, &mask);
        calculate_thread=6;
        maxquerythread=6;
    }
    else if(cpu_control_type==62)
    {
        CPU_SET(0, &mask);
        CPU_SET(1, &mask);
        CPU_SET(2, &mask);
        CPU_SET(3, &mask);
        CPU_SET(4, &mask);
        CPU_SET(5, &mask);
        calculate_thread=6;
        maxquerythread=6;
    }
    else if (cpu_control_type==81)
    {
        CPU_SET(0, &mask);
        CPU_SET(2, &mask);
        CPU_SET(4, &mask);
        CPU_SET(6, &mask);
        CPU_SET(8, &mask);
        CPU_SET(10, &mask);
        CPU_SET(12, &mask);
        CPU_SET(14, &mask);
        calculate_thread=8;
        maxquerythread=8;
    }
    else if (cpu_control_type==82)
    {
        CPU_SET(0, &mask);
        CPU_SET(1, &mask);
        CPU_SET(2, &mask);
        CPU_SET(3, &mask);
        CPU_SET(4, &mask);
        CPU_SET(5, &mask);
        CPU_SET(6, &mask);
        CPU_SET(7, &mask);
        calculate_thread=8;
        maxquerythread=8;
    }
    else if (cpu_control_type==101)
    {
        CPU_SET(0, &mask);
        CPU_SET(2, &mask);
        CPU_SET(4, &mask);
        CPU_SET(6, &mask);
        CPU_SET(8, &mask);
        CPU_SET(10, &mask);
        CPU_SET(12, &mask);
        CPU_SET(14, &mask);
        CPU_SET(16, &mask);
        CPU_SET(18, &mask);
        calculate_thread=10;
        maxquerythread=10;
    }
    else if (cpu_control_type==102)
    {
        CPU_SET(0, &mask);
        CPU_SET(1, &mask);
        CPU_SET(2, &mask);
        CPU_SET(3, &mask);
        CPU_SET(4, &mask);
        CPU_SET(5, &mask);
        CPU_SET(6, &mask);
        CPU_SET(7, &mask);
        CPU_SET(8, &mask);
        CPU_SET(9, &mask);
        calculate_thread=10;
        maxquerythread=10;
    }
    else if (cpu_control_type==121)
    {
        CPU_SET(0, &mask);
        CPU_SET(2, &mask);
        CPU_SET(4, &mask);
        CPU_SET(6, &mask);
        CPU_SET(8, &mask);
        CPU_SET(10, &mask);
        CPU_SET(12, &mask);
        CPU_SET(14, &mask);
        CPU_SET(16, &mask);
        CPU_SET(18, &mask);
        CPU_SET(20, &mask);
        CPU_SET(22, &mask);
        calculate_thread=12;
        maxquerythread=12;
    }
    else if (cpu_control_type==122)
    {
        CPU_SET(0, &mask);
        CPU_SET(1, &mask);
        CPU_SET(2, &mask);
        CPU_SET(3, &mask);
        CPU_SET(4, &mask);
        CPU_SET(5, &mask);
        CPU_SET(6, &mask);
        CPU_SET(7, &mask);
        CPU_SET(8, &mask);
        CPU_SET(9, &mask);
        CPU_SET(10, &mask);
        CPU_SET(11, &mask);
        calculate_thread=12;
        maxquerythread=12;
    }
    else if (cpu_control_type==182)
    {
            CPU_SET(0, &mask);
            CPU_SET(1, &mask);
            CPU_SET(2, &mask);
            CPU_SET(3, &mask);
            CPU_SET(4, &mask);
            CPU_SET(5, &mask);
            CPU_SET(6, &mask);
            CPU_SET(7, &mask);
            CPU_SET(8, &mask);
            CPU_SET(9, &mask);
            CPU_SET(10, &mask);
            CPU_SET(11, &mask);
            CPU_SET(12, &mask);
            CPU_SET(13, &mask);
            CPU_SET(14, &mask);
            CPU_SET(15, &mask);
            CPU_SET(16, &mask);
            CPU_SET(17, &mask);
            calculate_thread=18;
            maxquerythread=18;
    }
    else if (cpu_control_type==242)
    {
            CPU_SET(0, &mask);
            CPU_SET(1, &mask);
            CPU_SET(2, &mask);
            CPU_SET(3, &mask);
            CPU_SET(4, &mask);
            CPU_SET(5, &mask);
            CPU_SET(6, &mask);
            CPU_SET(7, &mask);
            CPU_SET(8, &mask);
            CPU_SET(9, &mask);
            CPU_SET(10, &mask);
            CPU_SET(11, &mask);
            CPU_SET(12, &mask);
            CPU_SET(13, &mask);
            CPU_SET(14, &mask);
            CPU_SET(15, &mask);
            CPU_SET(16, &mask);
            CPU_SET(17, &mask);
            CPU_SET(18, &mask);
            CPU_SET(19, &mask);
            CPU_SET(20, &mask);
            CPU_SET(21, &mask);
            CPU_SET(22, &mask);
            CPU_SET(23, &mask);
            calculate_thread=24;
            maxquerythread=24;
    }



			trillion(argv[1], argv[2], size,type,threshold,ts_num,full_time_series_size,query_number,calculate_thread);



            //system(mkdircommand);
		//printf("cpvalue is :  %s\n",cpvalue);
            //system(cpvalue);
		}
	}

}

// type 0 = epsilon-range query
// type 1 = K-NN query (the threshold here is the K)

int trillion( char const * datasetFile, char const * queryFile, int m, int type, double threshold, int ts_num, int full_time_series_size, int query_number, int calculate_thread)
{

	FILE *fp;              // the input file pointer
	FILE *qp;              // the query file pointer

	FILE *  queryAnswerFile;
	FILE *  completeStatFile;

    datafilegl= datasetFile;
    mgl=m;
    full_time_series_sizegl=full_time_series_size;
    typegl=type;

	char nameFileQueryResult[255];
	char const * nnameQueryCompleteStat = "completeStatTRILLION";
	time_t rawtime;
	time (&rawtime);
	struct tm* readable;
	readable = localtime(&rawtime);
	sprintf(nameFileQueryResult,"QueryResult_TRILLION_%d",readable->tm_hour);
    thresholdgl=threshold;
	queryAnswerFile = fopen(nameFileQueryResult,"a");
	completeStatFile = fopen(nnameQueryCompleteStat,"a");


	pqueue_t * resultQueue;

	double *Q;             // query array
	double *T;             // array of current data
	int *order;            // ordering of query by |z(q_i)|
	double bsf;            // best-so-far

	long long loc;     // answer: location of the best-so-far match
	long long dataScanned = 0;
	double d;
	long long i , j ;
	double ex , ex2 , mean, std;

	double t1,t2;
	double t1D,t2D;
	double sumCPUTime = 0;
	double sumDiskTime = 0;
	double averagePercentagePruning = 0;
	long long pointCheckedTotal = 0;
	long long avTotResult = 0;
    pthread_t threadid[calculate_thread];

	qp = fopen(queryFile,"rb");
	if( qp == NULL )
	{ 
		error(3);
		exit(1); // maybe not needed alredy present in error(int arg)
	}

	char * line=NULL;
	size_t len=0;
    int read;
    int lineCounter = 0;
    int q_loaded=0;
    long long totalDataPatterns;
        fseek(qp, 0L, SEEK_END);
    unsigned long long sz = (unsigned long long) ftell(qp);
    unsigned long long total_records = sz/1024;
    fseek(qp, 0L, SEEK_SET);

    //while((read = getline(&line, &len, qp))!=-1) 
    while (q_loaded < query_number)
    {
        q_loaded++;
        totalDataPatterns = 0;
        pointCheckedTotal = 0;
        dataScanned = 0; 
        lineCounter++;
        fp = fopen(datasetFile,"r");
        float * ts = (float*)malloc(sizeof(float) * 256);
        if( fp == NULL )
        {
            error(2);
            exit(1); // maybe not needed alredy present in error(int arg)
        }

        double * firsKResults;

        if (type == 0)
        {
            bsf = (threshold*threshold); // the sqrt is computed at the end!!!
        }
        else
        {
            bsf = INF;
            firsKResults = (double *)malloc(threshold*sizeof(double));
            int i=0;
            for(i=0;i<threshold;i++)
            {
                firsKResults[i] = -1.0;
            }
        }
        
        
        i = 0;
        j = 0;
        ex = ex2 = 0;

        // file should be binary and it
        // has to start with number of series contained
        // and for every series the length has to be at the first place.
        //t1 = clock();
        COUNT_TOTAL_TIME_START
        /// Array for keeping the query data
        Q = (double *)malloc(sizeof(double)*m);

        fread(ts, sizeof(float),256,qp);

        if( Q == NULL )
            error(1);

        for (i = 0; i < 256; i++)
        {
            Q[i]=(double)ts[i];
            //ex=ex+Q[i];
            //ex2 += Q[i]*Q[i];
        }
        /// Read the query data from input file and calculate its statistic such as mean, std
        // the query series has the points (real numbers) separated with a space
        //char *olds = line;
	       //char olddelim = ' ';
	       //while(olddelim && *line) {
		//while(*line && (' ' != *line)) line++;
		//*line ^= olddelim = *line; 
		//cb(olds);
                //d = atof(olds);
                //ex += d;
                //ex2 += d*d;
                //Q[i] = d;
                //i++;
                
		//*line++ ^= olddelim; 
		//olds = line;
	   //}
        line = NULL;
        
        mean = ex/m;
        std = ex2/m;
        std = sqrt(std-mean*mean);
 

        /// Do z_normalization on query data
        //for( i = 0 ; i < m ; i++ )
             //Q[i] = (Q[i] - mean)/std;

        /// Sort the query data
        order = (int *)malloc(sizeof(int)*m);
        if( order == NULL )
            error(1);
        Index *Q_tmp = (Index *)malloc(sizeof(Index)*m);
        if( Q_tmp == NULL )
            error(1);
        for( i = 0 ; i < m ; i++ )
        {
            Q_tmp[i].value = Q[i];
            Q_tmp[i].index = i;
        }
        qsort(Q_tmp, m, sizeof(Index),comp);
        for( i=0; i<m; i++)
        {   
            Q[i] = Q_tmp[i].value;
            order[i] = Q_tmp[i].index;
        }
        free(Q_tmp);

        /// Array for keeping the current data; Twice the size for removing modulo (circulation) in distance calculation
        T = (double *)malloc(sizeof(double)*2*m);
        if( T == NULL )
            error(1);

        double dist = 0;
        i = 0;
        j = 0;
        ex = ex2 = 0;
        t2D = 0;
        resultQueue = pqueue_init(ts_num,cmp_pri, get_pri, set_pri, get_pos, set_pos);
        int in;

        //for(in=0;in<ts_num;in++)
        if(calculate_thread!=1)
        {
            transfordata *transferdatamlt=(transfordata*)malloc(sizeof(transfordata)*(calculate_thread));
            pthread_mutex_t lock_bsf=PTHREAD_MUTEX_INITIALIZER;
            for (i = 0; i < (calculate_thread); i++)
            {
                transferdatamlt[i].lock_bsf=&lock_bsf;
                transferdatamlt[i].start_number=i*(ts_num/calculate_thread);
                transferdatamlt[i].stop_number=(i+1)*(ts_num/calculate_thread);
                transferdatamlt[i].resultQueue=resultQueue;
                transferdatamlt[i].bsfdistance= &bsf;
                transferdatamlt[i].totalDataPatterns=0;
                transferdatamlt[i].firsKResults=firsKResults;
                transferdatamlt[i].Q=Q;
                transferdatamlt[i].order=order;
            }
            transferdatamlt[calculate_thread-1].lock_bsf=&lock_bsf;
            transferdatamlt[calculate_thread-1].start_number=(calculate_thread-1)*(ts_num/calculate_thread);
            transferdatamlt[calculate_thread-1].stop_number=ts_num;
            transferdatamlt[calculate_thread-1].resultQueue=resultQueue;
            transferdatamlt[calculate_thread-1].bsfdistance=&bsf;
            transferdatamlt[calculate_thread-1].totalDataPatterns=0;
            transferdatamlt[calculate_thread-1].firsKResults=firsKResults;
            transferdatamlt[calculate_thread-1].Q=Q;
            transferdatamlt[calculate_thread-1].order=order;
            void* templetransferdatamlt;
            for(i=0; i<calculate_thread; i++) 
            {
                pthread_create(&(threadid[i]),NULL,query_time_series,(void*)(&transferdatamlt[i]));
            }

            for (i = 0; i < calculate_thread; i++)
            {
                pthread_join(threadid[i],NULL);
                totalDataPatterns=totalDataPatterns+transferdatamlt[i].totalDataPatterns;
                pointCheckedTotal=pointCheckedTotal+transferdatamlt[i].pointCheckedTotal;
            }
                    //printf(" Distance: %f \n\n",bsf);   
        }
        else
        {
            for(in=0;in<ts_num;in++)
            {
                int jn;
                i = 0;
                j = 0;
                ex = ex2 = 0;
                float * app = (float *) malloc(full_time_series_size*sizeof(float));
                t1D = clock();
                fread(app, full_time_series_size*sizeof(float), 1, fp);
                t2D = t2D + (clock() - t1D);
                for(jn=0;jn<full_time_series_size;jn++)
                {
                    dataScanned = dataScanned + 1;
               
                    d = (double) app[jn];
                    //ex += d;
                    //ex2 += d*d;
                    T[i%m] = d;
                    T[(i%m)+m] = d;

                    /// If there is enough data in T, the ED distance can be calculated
                    if( i >= m-1 )
                    {
                    /// the current starting location of T
                        j = (i+1)%m;

                    /// Z_norm(T[i]) will be calculated on the fly
                    //mean = ex/m;
                    //std = ex2/m;
                    //std = sqrt(std-mean*mean);

                    /// Calculate ED distance
                        int pointChecked;
                        totalDataPatterns = totalDataPatterns + m;
                        dist = distancenormal(Q,T,j,m,order,bsf,pointChecked);
                        pointCheckedTotal = pointCheckedTotal + (long long) pointChecked;
                    
                        _Bool bCHeck;
                    
                        if (type == 0)
                        {
                            bCHeck = dist <= bsf;
                        }
                        else
                        {
                            bCHeck = dist < bsf;
                        }
                    
                        if(bCHeck)
                        {
                            loc=(in*full_time_series_size)+(i-m+1);
                            query_result * result = (query_result *) malloc(sizeof(query_result));
                            result->distance = dist;
                            result->location = loc;
                            result->sizeOfQuery = m;
                            pqueue_insert(resultQueue, result);
                            if (type != 0)
                            {
                                //in case of K-NN query keep the Kth distance found
                                int k = (int) threshold;
                                pushDistValueInTheTopK(firsKResults,k,dist);
                                if (firsKResults[k-1] >= 0)
                                {
                                    bsf = firsKResults[k-1];
                                }
                            }
  
                        }
                    //ex -= T[j];
                    //ex2 -= T[j]*T[j];
                    }
                i++;
                }
                free(app);
            }
        }
        //t2 = clock();
        COUNT_TOTAL_TIME_END
        double totalExecutionTime = total_time/1000000;
        double totalDiskTime = t2D/CLOCKS_PER_SEC;
        
        //cout << "Result query # "<< lineCounter <<" filename: "<<queryFile<<endl;
        //fprintf(queryAnswerFile,"Result query # %i filename: %s\n",lineCounter,queryFile);
        if (type == 0)
        {
             //cout << "Type of query: Epsilon-range="<<threshold<<endl;
             //fprintf(queryAnswerFile,"Type of query: Epsilon-range=%f",threshold);
        }
        else
        {
            //cout << "Type of query: K-NN= "<<threshold<<endl;
            //fprintf(queryAnswerFile,"Type of query: K-NN=%f\n",threshold);
        }
        
        
        double pp = (100.0 - (((double)pointCheckedTotal*100.0)/(double)totalDataPatterns));
       
        
        
        //cout << "Data Scanned: " << dataScanned << endl;
        cout << "Total Execution Time : " << totalExecutionTime<< " sec" << endl;
        //cout << "Total Disk Time : " << totalDiskTime << " sec" << endl;
        //cout << "Total CPU Time : " << totalExecutionTime-totalDiskTime << " sec" <<endl;
        //cout << "Pruning power (abandoning power) : " << pp << "%" << endl<<endl;
        
        //fprintf(queryAnswerFile,"Data Scanned: %lld \n", dataScanned);
        //printf(queryAnswerFile,"Total Execution Time : %f sec \n", totalExecutionTime);
        //fprintf(queryAnswerFile,"Total Disk Time: %f sec \n", totalDiskTime);
        //fprintf(queryAnswerFile,"Total CPU Time: %f sec \n", totalExecutionTime-totalDiskTime);
        //fprintf(queryAnswerFile,"Pruning power (abandoning power) : %f perc \n",pp );
        query_result * qr;


        
        
        averagePercentagePruning = averagePercentagePruning + pp;
        
        if (type == 0)
        {
            cout << "Number of result eps-query: " << (resultQueue->size-1) << endl;
            //fprintf(queryAnswerFile,"Number of result eps-query: %zu \n", (resultQueue->size-1));
            avTotResult = avTotResult + (resultQueue->size-1);
        }
        sumCPUTime = sumCPUTime + (totalExecutionTime-totalDiskTime);
        sumDiskTime = sumDiskTime + totalDiskTime;
        
        long long cont =0;
        
        float prevDist = 0.0;
        
        
        if (type ==1 || (type ==0 && ((resultQueue->size-1) <= 10)))
        {
            while (( qr = (query_result *)pqueue_pop(resultQueue)))
            {
                if(cont>0 && (type ==1))
                {
                    if (cont>=threshold && qr->distance>prevDist)
                    {
                        break;
                    }
                }
                printf(" Size of query: %i ",qr->sizeOfQuery); 
                printf(" Location: %llu ",qr->location);
                printf(" Distance: %f \n",qr->distance);
                //fprintf(queryAnswerFile," Size of query: %i ",qr->sizeOfQuery); 
                //fprintf(queryAnswerFile," Location: %llu ",qr->location);
                //fprintf(queryAnswerFile," Distance: %f \n",qr->distance);

                prevDist = qr->distance;
                free(qr);
                cont++;
            }
        }
        else
        {
            printf(" Results omitted!! \n\n");
            fprintf(queryAnswerFile,"Results omitted!! \n\n");
        }
        
        
        while (( qr = (query_result *)pqueue_pop(resultQueue)) )
        {
            free(qr);
        }
        if(resultQueue != NULL)
        {
            free (resultQueue->d);
            free(resultQueue);
        }
        if(type!=0)
        {
            free(firsKResults);
        }
        
        //cout <<"##################"<< endl<<endl;
        //fprintf(queryAnswerFile,"##################\n");
        fclose(fp);
        free(Q);
    }
    
    if (lineCounter>0)
    {
        //cout << "Average result of queries in the file: "<<queryFile<<" on the dataset: "<<datasetFile<<endl;
        //cout << "Disk time: "<<sumDiskTime/lineCounter<<endl;
        //cout << "CPU time: "<<sumCPUTime/lineCounter<<endl;
        //cout << "Total time: \n"<<(total_time/1000000)+(sumCPUTime/lineCounter)<<endl;
        //cout << "Average Pruning power (abandoning power) : " << (averagePercentagePruning/(double)lineCounter) <<"perc" << endl<<endl;
        
        // fprintf(completeStatFile,"Average result of queries in the file: %s on the dataset: %s\n",queryFile,datasetFile); 
        //fprintf(completeStatFile,"Disk time %f \n",sumDiskTime/lineCounter); 
        //fprintf(completeStatFile,"CPU time %f \n",sumCPUTime/lineCounter); 
        //fprintf(completeStatFile,"Total time: %f \n",(sumDiskTime/lineCounter)+(sumCPUTime/lineCounter)); 
        //fprintf(completeStatFile,"Average Pruning power (abandoning power) : %f perc\n",(averagePercentagePruning/(double)lineCounter)); 
    
        if (type == 0)
        {
             cout << "Average number of result eps-query: " << (avTotResult/lineCounter) << endl;
             fprintf(completeStatFile,"Average number of result eps-query: %lld\n",(avTotResult/lineCounter)); 
        }
        cout<<"##########################################################################"<<endl;
        fprintf(completeStatFile,"##########################################################################\n\n"); 
        
    }
    
    fclose(qp);
    fclose(queryAnswerFile);
    fclose(completeStatFile);
	
}

int simpleScan( char const * datasetFile, int ts_num, int full_time_series_size)
{

	FILE *fp;      // the input file pointer
	double t1D,t2D;
    t2D = 0;
   	int in;
	t1D = clock();
	fp = fopen(datasetFile,"r");
	
	for(in=0;in<ts_num;in++)
	{
		float * app = (float *) malloc(sizeof(float)*full_time_series_size);
		fread(app, (sizeof(float)*full_time_series_size), 1, fp);
		free(app);
	}
	t2D = t2D + (clock() - t1D);
	double totalDiskTime = t2D/CLOCKS_PER_SEC;
	cout << "Total Scan Time : " << totalDiskTime << " sec" << endl;
	fclose(fp);
      
}

void * query_time_series(void *transferdatamlt)
{

    unsigned long in=0;
    long long i,j,loc;
    unsigned long start_number=((transfordata*)transferdatamlt)->start_number;
    unsigned long stop_number=((transfordata*)transferdatamlt)->stop_number;
    double * firsKResults=((transfordata*)transferdatamlt)->firsKResults;
    pqueue_t * resultQueue=((transfordata*)transferdatamlt)->resultQueue;
    FILE *fp = fopen(datafilegl, "rb");
    fseek(fp, 0, SEEK_SET);
    int m=mgl;
    int full_time_series_size=full_time_series_sizegl;
    int k = (int) thresholdgl;
    int type=typegl;
    double bsf=*(((transfordata*)transferdatamlt)->bsfdistance);
    double d,dist;
    double *T=(double *)malloc(sizeof(double)*2*m);
    double *Q=((transfordata*)transferdatamlt)->Q;
    int * order=((transfordata*)transferdatamlt)->order;
    for(in=start_number;in<stop_number;in++)
    {
        int jn;
        i = 0;
        j = 0;
        float * app = (float *) malloc(full_time_series_size*sizeof(float));
        fseek(fp, in * 1024, SEEK_SET);
        fread(app, full_time_series_size*sizeof(float), 1, fp);
        for(jn=0;jn<full_time_series_size;jn++)
        {
            d = (double) app[jn];

            T[i%m] = d;
            T[(i%m)+m] = d;

            /// If there is enough data in T, the ED distance can be calculated
            if( i >= m-1 )
            {
                    /// the current starting location of T
                j = (i+1)%m;

                    /// Z_norm(T[i]) will be calculated on the fly

                    /// Calculate ED distance
                int pointChecked;
                ((transfordata*)transferdatamlt)->totalDataPatterns = ((transfordata*)transferdatamlt)->totalDataPatterns + m;
                dist = distancenormal(Q,T,j,m,order,bsf,pointChecked);
                ((transfordata*)transferdatamlt)->pointCheckedTotal = ((transfordata*)transferdatamlt)->pointCheckedTotal + (long long) pointChecked;
                _Bool bCHeck;
                    
                if (type == 0)
                {
                    bCHeck = dist <= bsf;
                }
                else
                {
                    bCHeck = dist < bsf;
                }
                if(bCHeck)
                {   
                    pthread_mutex_lock(((transfordata*)transferdatamlt)->lock_bsf);
                    if (dist<*(((transfordata*)transferdatamlt)->bsfdistance))
                    {   
                        loc=(in*full_time_series_size)+(i-m+1);
                        query_result * result = (query_result *) malloc(sizeof(query_result));
                        result->distance = dist;
                        result->location = loc;
                        result->sizeOfQuery = m;
                        pqueue_insert(resultQueue, result);                            
                        if (type != 0)
                        {
                            //in case of K-NN query keep the Kth distance found

                            pushDistValueInTheTopK(firsKResults,k,dist);
                            if (firsKResults[k-1] >= 0)
                            {
                                bsf = firsKResults[k-1];
                            }
                            *(((transfordata*)transferdatamlt)->bsfdistance)=bsf;
                        }
                    }
                    else
                    {
                        bsf=*(((transfordata*)transferdatamlt)->bsfdistance);
                    }
                    pthread_mutex_unlock(((transfordata*)transferdatamlt)->lock_bsf);
  
                }

            }
            i++;
        }
        free(app);
    }
    free(T);
}
