example of the command:

./dist/Debug/Cygwin-Windows/trillionnew dataset1000.bin queryexample.bin 256 1 1 1000 256 1 21



